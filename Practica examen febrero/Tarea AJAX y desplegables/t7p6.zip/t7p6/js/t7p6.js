document.addEventListener("DOMContentLoaded", iniciar, false);

function iniciar() {
  document.getElementById("id_ccaa").addEventListener("change", fccaa);
  document
    .getElementById("id_provincia")
    .addEventListener("change", fprovincia);
  document
    .getElementById("id_municipio")
    .addEventListener("change", fmunicipio);

  //Cargamos el select de comunidades autónomas
  var pag = "php/getCcaa.php";
  datos = "nocache=" + Math.random();
  loadDoc(pag, datos, mostrar_ccaa);
}

function mostrar_ccaa(xhttp) {
  var datos = JSON.parse(xhttp.responseText);
  for (let i = 0; i < datos.length; i++) {
    var option = document.createElement("option");
    option.setAttribute("value", datos[i].id);
    var texto = document.createTextNode(datos[i].comunidad);
    option.appendChild(texto);
    document.getElementById("id_ccaa").appendChild(option);
  }
}

function fccaa() {}

function fprovincia() {}

function fmunicipio() {}
